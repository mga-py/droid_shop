package com.rangelpinillabaltasar.droid_shop_prueba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "errores";
    private Gson gson = new Gson();
    private ListView lvLineaPedido ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvLineaPedido = findViewById(R.id.lv_lineaPedido);
        getMensajes();



    }


    public void getMensajes() {
        Toast.makeText(MainActivity.this, "Empezando.....", Toast.LENGTH_SHORT).show();
        VolleySingleton.getInstance(this.getApplicationContext()).addToRequestQueue(
                new JsonObjectRequest(Request.Method.GET, Constantes.GET, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                procesarRespuesta(response); // Procesar la respuesta Json
                                Toast.makeText(MainActivity.this, "PROCESANDOO.....", Toast.LENGTH_SHORT).show();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.d(TAG, "Error Volley: " + error.getMessage());
                            }
                        }

                )
        );
    }

    private void procesarRespuesta(JSONObject response) {
        try {
            Log.d(TAG, "Respuesta: " + response.toString());
            String estado = response.getString("estado");

            switch (estado) {
                case "1": // correcto
                    JSONArray mensaje = response.getJSONArray("linea_pedido");
                    LineaPedido[] mensajes = gson.fromJson(mensaje.toString(), LineaPedido[].class); // preparar con Gson
                    // Inicializar adaptador
                    ArrayAdapter<LineaPedido> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,mensajes);

                    lvLineaPedido.setAdapter(adapter);
                    break;
                case "2": // error
                    String mensaje2 = response.getString("mensaje");
                    Toast.makeText(
                            getApplicationContext(),

                            mensaje2,
                            Toast.LENGTH_LONG).show();
                    break;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
